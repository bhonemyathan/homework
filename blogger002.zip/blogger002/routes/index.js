var express = require("express");
const { findById } = require("../models/User");
var router = express.Router();
var User = require("../models/User");

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("index", { title: "Express" });
});

router.get("/register", (req, res) => {
  res.render("register");
});

router.post("/register", (req, res) => {
  const users = new User();
  users.name = req.body.uname;
  users.email = req.body.uemail;
  users.password = req.body.password;
  users.save((err, rtn) => {
    if (err) throw err;
    console.log(rtn);
    res.redirect("/");
  });
});

router.get("/list", (req, res) => {
  User.find({}, (err, rtn) => {
    if (err) throw err;
    console.log(err);
    res.render("list", { users: rtn });
  });
});

router.get("/userdetail/:id", (req, res) => {
  User.findById(req.params.id, (err, rtn) => {
    if (err) throw err;
    res.render("userdetail", { user: rtn });
  });
});

router.get("/userupdate/:id", (req, res) => {
  User.findById(req.params.id, (err,rtn) => {
    if(err) throw err;
    res.render("userupdate", {user: rtn});
  });
});

router.post("/userupdate", (req,res) => {
  const update = {
    name: req.body.uname,
    email: req.body.uemail,
    password: req.body.pwd
  }
  User.findByIdAndUpdate(req.body.id, {$set: update}, (err,rtn) => {
    if(err) throw err;
    res.redirect("/list");
  })
})

router.get("/userdelete/:id", function (req, res) {
  User.findByIdAndDelete(req.params.id, function (err, rtn) {
    if (err) throw err;
    console.log(req.params.id);
    res.redirect("/list");
  });
});

module.exports = router;
